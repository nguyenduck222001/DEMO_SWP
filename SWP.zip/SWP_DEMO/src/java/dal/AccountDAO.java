package dal;

import model.Account;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AccountDAO extends DBContext {

    // Lấy tài khoản theo email và mật khẩu
    public Account getAccountByEmailAndPassword(String email, String password) {
        Account account = null;
        String query = "SELECT * FROM Users WHERE Email = ? AND Password = ?";

        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, email);
            statement.setString(2, password);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    int id = resultSet.getInt("UserID");  // Giả sử 'UserID' là ID của người dùng trong bảng 'Users'
                    String fullname = resultSet.getString("FullName");
                    String phoneNumber = resultSet.getString("PhoneNumber");
                    String address = resultSet.getString("Address");
                    String gender = resultSet.getString("Gender");
                    Date dateOfBirth = resultSet.getDate("DateOfBirth");
                    String role = resultSet.getString("Role");
                    String status = resultSet.getString("Status");
                    Timestamp createdAt = resultSet.getTimestamp("CreatedAt");
                    Timestamp updatedAt = resultSet.getTimestamp("UpdatedAt");

                    // Tạo đối tượng Account với dữ liệu từ bảng Users
                    account = new Account(id, fullname, email, phoneNumber, password, gender, address, dateOfBirth, role, status, createdAt, updatedAt);
                }
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        return account;
    }

    // Cập nhật tài khoản theo ID (cập nhật thông tin người dùng)
    public boolean updateAccount(int userId, String name, String email, String address) {
        try (PreparedStatement stmt = connection.prepareStatement("UPDATE Users SET FullName = ?, Email = ?, Address = ? WHERE UserID = ?")) {
            stmt.setString(1, name);
            stmt.setString(2, email);
            stmt.setString(3, address);
            stmt.setInt(4, userId);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Kiểm tra sự tồn tại của người dùng theo username
    public boolean isUserAdded(String username) {
        String query = "SELECT COUNT(*) FROM Users WHERE Email = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, username);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    int count = resultSet.getInt(1);
                    return count > 0;
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return false;
    }

    // Thêm tài khoản mới vào cơ sở dữ liệu
    public boolean addAccount(Account account) {
        boolean success = false;
        String query = "INSERT INTO Users (FullName, Email, PhoneNumber, Password, Gender, Address, DateOfBirth, Role, Status, CreatedAt, UpdatedAt) " +
                       "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, account.getFullname());
            statement.setString(2, account.getEmail());
            statement.setString(3, account.getPhoneNumber());
            statement.setString(4, account.getPassword());
            statement.setString(5, account.getGender());
            statement.setString(6, account.getAddress());
            statement.setDate(7, new java.sql.Date(account.getDateOfBirth().getTime()));
            statement.setString(8, account.getRole());
            statement.setString(9, account.getStatus());
            statement.setTimestamp(10, account.getCreatedAt());
            statement.setTimestamp(11, account.getUpdatedAt());

            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                success = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return success;
    }

    // Cập nhật mật khẩu tài khoản
    public boolean updatePassword(int userId, String newPassword) {
        try (PreparedStatement stmt = connection.prepareStatement("UPDATE Users SET Password = ? WHERE UserID = ?")) {
            stmt.setString(1, newPassword);
            stmt.setInt(2, userId);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static void main(String[] args) {
        AccountDAO dao = new AccountDAO();
        System.out.println(dao.updatePassword(11, "newPassword"));
    }
}
